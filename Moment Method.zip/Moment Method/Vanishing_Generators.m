function Random_Polynomials = Vanishing_Generators(Zero_Set,Variables,A,Degree,tol)

  % Constructs a square system with bounded degree of random polynomials using the Vandermonde matrix

  % The zero set is a matrix of points, where the rows of the matrix consists of the points

number_of_Monomials = size(A);
  Monomials = [];
for k = 1:number_of_Monomials(1)
    if isequal(A(k,:),zeros(1,Variables)) == 1
    Monomials = [Monomials ; A(k,:) 0];
    else
    Monomials = [Monomials ; A(k,:) 1];
    endif

endfor

for i = 2:Degree
  Monomials = Adding_A(Monomials,A,i,Variables);
endfor
  Size_of_Monomials = size(Monomials);
  Monomials = Monomials(:,1:Variables);
  Number_of_Zeros = size(Zero_Set); % number of colums is the numbers of zeros

  % constructing the vandermonde matrix where the columns are indexed by the monomials and
  % the rows are indexed by the points

  Vandermonde = [zeros(Number_of_Zeros(1),Size_of_Monomials(1))];

  for i = 1:Number_of_Zeros(1)
    for j = 1:Size_of_Monomials(1)
        Vandermonde(i,j) = evaluation({{1,Monomials(j,1:Variables)}},Zero_Set(i,:),Variables);
    endfor
  endfor


  Basis_of_Kernel = null(Vandermonde); % solutions are the column vectors
  size_of_Basis = size(Basis_of_Kernel);

  if size_of_Basis(2) < Variables
    printf ("dimension error\n");
    return
  endif

  Random_Polynomials = {};
  for k = 1:Variables
        random_coefficients = 10*rand(1,size_of_Basis(2)) - 5;
        random_coefficients = Basis_of_Kernel * random_coefficients';
        random_polynomial = {};
        for monomial = 1:Size_of_Monomials(1)
            random_polynomial{monomial} = {random_coefficients(monomial),Monomials(monomial,:)};
        endfor
        Random_Polynomials{k} = random_polynomial;
  endfor
  random_coefficient = rand;
  for monomial = 1:size_of_Basis(1)

      random_polynomial{monomial} = {random_coefficient * Basis_of_Kernel(monomial,1),Monomials(monomial,:)};
  endfor
  Random_Polynomials{Variables+1} = random_polynomial;


endfunction
