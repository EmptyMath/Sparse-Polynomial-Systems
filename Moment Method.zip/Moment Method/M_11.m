function [P_1,M_new,P_2] = M_11(M);

% M ~= 0!

% this function checks if the entry m_11 is equal to zero or not. In the
% case m_11 = 0, we return permutation matrices P_1 and P_2 such that P_1 *
% M * P_2 = M_new has the entry M_new_11 ~= 0.

row_and_columns = size(M);

if M(1,1) ~= 0
    P_1 = eye(row_and_columns(1),row_and_columns(2));
    P_2 = eye(row_and_columns(1),row_and_columns(2));
    M_new = M;
else
    k = 0;
    l= 0;
   for i = 1:row_and_columns(1)
       for j = 1:row_and_columns(2)
           if M(i,j) ~= 0
               k = i;
               l = j;
           end          
       end
   end

P_1 = eye(row_and_columns(1),row_and_columns(2));
P_2 = eye(row_and_columns(1),row_and_columns(2));

% exhange row 1 with row k

if k ~= 1
P_1(1,1) = 0;
P_1(k,1) = 1;
P_1(1,k) = 1;
P_1(k,k) = 0;
end

% exchange column 1 with l

if l ~= 1
P_2(1,1) = 0;
P_2(l,1) = 1;
P_2(1,l) = 1;
P_2(l,l) = 0;
end

P_1 
P_2

M_new = P_1 * M * P_2

end



end