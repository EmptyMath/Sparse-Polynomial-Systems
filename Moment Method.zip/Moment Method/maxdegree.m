function D = maxdegree(exponents)

% outputs the maximal degree of exponent vectors
% the exponents are given in the form {{alpha_1},...,{alpha_n}}

D = 0;
for i = 1:numel(exponents)
    D = max(D,norm(exponents{i},1));
end