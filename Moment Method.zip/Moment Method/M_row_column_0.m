function [L,M,R] = M_row_column_0(L,M,R);

% this function transforms M such that every entry in the first column and
% row is equal to uero, where we assume that M_11 divides all entries in M

row_and_column = size(M);

% first column = 0

for i = 1:row_and_column(1)
    if i > 1
     T = eye(row_and_column(1),row_and_column(2));
     T(i,1) = -(M(i,1)/ M(1,1));
     L = T * L;
     M = T * M;
    end
end

% first row = 0

for j = 1:row_and_column(2)
    if j > 1
     T = eye(row_and_column(1),row_and_column(2));
     T(1,j) = -(M(1,j)/ M(1,1));
     R = R * T;
     M = M * T;
    end
end

end