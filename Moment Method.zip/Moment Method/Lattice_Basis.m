function Basis = Lattice_Basis(M)

% this function computes the lattice basis of a generator system M,
% represented by column vectros 

r = rank(M);

% we are now reordering M in such a way that the first r columns are
% linearly independet, represented by M_lin and the linear dependent
% columns are represented by M_lin_dep

M_lin = M(:,1);
M_lin_dep = [];

while rank(M_lin) < r 
    k = 2;
    if rank([M_lin M(:,k)]) > rank(M_reorderd)
       M_lin = [M_lin M(:,k)];
    else
        M_lin_dep = [M_lin_dep M(:,k)];
    end
end

M_reorderd = [M_lin M_lin_dep];

Q = linsolve(M_lin, M_reorderd);

end