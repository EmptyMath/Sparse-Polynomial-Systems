function Jacobi = Jacobi_Matrix_2(Polynomials,Variables,point)

% This function computes the Jacobi_Matrix w.r.t. a square systems of polynomials
% Let Polynomials = {f_1,...,f_n} in n Variables. Then the function computes the
% Jacobi matrix of the function (f_1,...,f_n) at the given point

  Jacobi = zeros(Variables,Variables);
  for i = 1:Variables % variable
    for j = 1:Variables % polynom
      Jacobi(i,j) = evaluation(Derivative_Polynomial(Polynomials{j},Variables,i),point,Variables);
    endfor
  endfor

endfunction
