function polynom = Adding_Polynomials(f,g)
  
  polynom = {};
  Mononmials = [];
  monomials_f = length(f);
  monomials_g = length(g);
  
  Monomials_f = [];
  Monomials_g = [];
  
  for i = 1:monomials_f
    Monomials_f = [Monomials_f;f{i}{2}];  
  endfor
  
  for j = 1:monomials_g
    Monomials_g = [Monomials_g;g{j}{2}];  
  endfor
  
  for i = 1:monomials_f
    
    monomial = f{i}{2};
    coefficent = f{i}{1};
      if ismember (monomial, Monomials_g, "rows") == 1
        for j = 1:monomials_g
          if ismember (monomial, g{j}{2}, "rows") == 1
              polynom{i} = {coefficent + g{j}{1}, monomial};
              Mononmials = [Mononmials; monomial];
          endif
        endfor
      else
        polynom{i} = f{i};
      endif
   endfor
  
  
  monomials_polynom = length(polynom);
  T = monomials_polynom + 1;
    for j = 1:monomials_g
    
    monomial = g{j}{2};
    coefficent = g{j}{1};
    
    
    

      J = ismember (monomial, Mononmials, "rows") + 1;
      if J == 1
        polynom{T} =  g{j};
        T = T + 1;
      endif

  endfor
      
    
  
endfunction
