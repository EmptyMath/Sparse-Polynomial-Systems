function [C,A] = function_test(c)

A = [2 3; 5 6];
C = [3;7];

end