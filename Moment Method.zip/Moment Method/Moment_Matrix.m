function M_lambda = Moment_Matrix(lambda,order,monomials)

% Input: a linear functional lambda, represented as a vector, with the
% columns indexed given by the monomial set monomials, represented as row
% vectors

% Output: the moment matrix of the given order corresponding to lambda

M_lambda = [];

number_of_monomials = size(monomials);

for i = 1:number_of_monomials(1)
    for j = 1:number_of_monomials(1)
        if norm(monomials(i,:),1) <= order & norm(monomials(j,:),1) <= order
        monomial = monomials(i,:) + monomials(j,:);
        if norm(monomial,1) <= 2*order
            k = 1;
        while isequal(monomial,monomials(k,:)) == 0
            k = k + 1;
        end
        M_lambda(i,j) = lambda(k);
        end
    end
end




end