function [L,M,R] = Smith_Normal(M)

% this function computes the smith normal form of M, and also returns L and
% R such that L * M * R = diag(= Output M)

rows_and_columns = size(M);

% at first L and R are just the identity matrix

L = eye(rows_and_columns(1),rows_and_columns(2));
R = L;

if isequal(M,zeros(rows_and_columns(1),rows_and_columns(2))) == 1
    D = M;
    return
end

% making sure the 11 entry is not zero

if M(1,1) == 0
    [L,M,R] = M_11(M);
end

% transforming M such that M_11 divides all entries in M

[L,M,R] = M_11_Divides_all(L,M,R);

% transforming M such that the first row and column equals 0 except M_11

[L,M,R] = M_row_column_0(L,M,R);

if rows_and_columns(1) > 1 & rows_and_columns(2) >1
    B = M(2:rows_and_columns(1),2:rows_and_columns(2));
    [L_1,B,R_1] = Smith_Normal(B);
    L = [1 zeros(1,rows_and_columns(2)-1) ; zeros(1,rows_and_columns(1)-1)' L_1] * L;
    R = R * [1 zeros(1,rows_and_columns(2)-1) ; zeros(1,rows_and_columns(1)-1)' R_1];
    M = [M(1,1) zeros(1,rows_and_columns(2)-1) ; zeros(1,rows_and_columns(1)-1)' B];
end





end