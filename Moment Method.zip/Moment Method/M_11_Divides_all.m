function [L,M_new,R] = M_11_Divides_all(L,M,R)

% irgendwo ist was falsch

% if M_11 ~= 0, this function computes L and R sucht that L*M*R = M_new and
% all entry in M_new are divisible by M_11

rows_and_columns = size(M);

% first checking the column

for i = 1:rows_and_columns(1)
    if mod(M(i,1),M(1,1)) ~= 0
       [d_i,Coefficient_i] = gcd(M(i,1),M(1,1));
       [d_1,Coefficient_1] = gcd(M(1,1),M(i,1));
       % we now have Coe_i*M(i,1) + Coe_1*M(1,1) = d_1

       T = eye(rows_and_columns(1),rows_and_columns(2));
       T(1,1) = Coefficient_1;
       T(1,i) = Coefficient_i;
       T(i,1) = - M(i,1) / d_1;
       T(i,i) = M(1,1) / d_1;
       L = T * L
       M
       M = T * M;
       M
    end
end

% cheching the first row

for j = 1:rows_and_columns(2)
    if mod(M(1,j),M(1,1)) ~= 0
        M(1,j)
        M(1,1)
       [d_j,Coefficient_j] = gcd(M(1,j),M(1,1));
       [d_1,Coefficient_1] = gcd(M(1,1),M(1,j));
       % we now have Coe_j*M(j,1) + Coe_1*M(1,1) = d_1

       T = eye(rows_and_columns(1),rows_and_columns(2));
       T(1,1) = Coefficient_1;
       T(j,1) = Coefficient_j;
       T(1,j) = - M(1,j) / d_1;
       T(j,j) = M(1,1) / d_1;
       R =R* T
       M
       M = M*T;
       M
    end
end
M

for i = 1:rows_and_columns(1)
    for j = 1:rows_and_columns(2)
        if mod(M(i,j),M(1,1)) ~= 0
            
            % substracting the (M(i,1) / M(1,1) - 1)*first row from the ith
            % row

            if M(i,1) == 0
                T = eye(rows_and_columns(1),rows_and_columns(2));
                T(i,1) = 1;
                L = T * L;
                M = T * M;
M
                [d_i,Coefficient_i] = gcd(M(i,1),M(i,j));
                [d_j,Coefficient_j] = gcd(M(i,j),M(i,1));

                T = eye(rows_and_columns(1),rows_and_columns(2));
                T(1,1) = Coefficient_i;
                T(1,j) = - M(i,j) / d_i;
                T(j,1) = Coefficient_j;
                T(j,j) = M(i,1) / d_i;
                R =R* T;
                M = M*T;
            else
                T = eye(rows_and_columns(1),rows_and_columns(2));
                T(i,1) = (M(i,1)/ M(1,1)) - 1;
                L = T * L;
                M = T * M;

                [d_i,Coefficient_i] = gcd(M(i,1),M(i,j));
                [d_j,Coefficient_j] = gcd(M(i,j),M(i,1));

                T = eye(rows_and_columns(1),rows_and_columns(2));
                T(1,1) = Coefficient_i;
                T(1,j) = - M(i,j) / d_i;
                T(j,1) = Coefficient_j;
                T(j,j) = M(i,1) / d_i;
                R =R* T;
                M = M*T;
            end
            [L,M,R] = M_11_Divides_all(L,M,R);
            break
            % we want to break this iteration right here, hence return
    end
end

M_new = M;

end