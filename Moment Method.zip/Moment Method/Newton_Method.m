function solution = Newton_Method(Polynomials,Variables,point,tol)

  % this function applies the newton method to a square system of polynomials

  Evaluations = zeros(Variables,1);
  for i = 1:Variables
    Evaluations(i) = evaluation(Polynomials{i},point,Variables);
  endfor
  solution = point;
  Evaluations_2 = Evaluations;
  
  while norm(Evaluations,2) > tol && norm(Evaluations,2) >= norm(Evaluations_2,2)
    f_p = zeros(Variables,1);
    for i = 1:Variables
      f_p(i) = evaluation(Polynomials{i},point,Variables);
    endfor

    solution = (Jacobi_Matrix_2(Polynomials,Variables,point) \ -(f_p));
    solution = solution + point';
    point = solution';
    Evaluations = Evaluations_2;
    for i = 1:Variables
    Evaluations_2(i) = evaluation(Polynomials{i},point,Variables);
  endfor
  Evaluations;
  solution;
  endwhile

endfunction
