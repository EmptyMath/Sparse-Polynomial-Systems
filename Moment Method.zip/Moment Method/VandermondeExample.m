% the Zero Set prescribes the Solutions of a random polynomial system constructed
% with the vandermonde matrix
Zero_Set = [1 2; 2 3; 1 -3; 4 5];

% Variables = Number of Coordinates of the solutions
Variables = 2;

% A = [0 0; 1 0; 0 1] since we want to focus on the standard moment approach first
% in general A = [0 ... 0; e_1 ; ... ; e_{Variables}]
A = [0 0;1 0;0 1];

% the total degree of the polynomials constructed with the Vandermonde Matrix
Degree = 5;



% tol prescribes the precision of the solutions
% it seems best to use bigger tol instead of smaller ones...
tol = 1e-3;

% Constructing a polynomial system using the vandermonde matrix consisting of
% Variables + 1 polynomials
Vandermonde = Vanishing_Generators(Zero_Set,Variables,A,Degree,tol);



% if random = 1, the SDP will be solved using a random vector (therefore, we
% expect only one solution to be computed)
% if random = 0, we use the standard moment method
random = 1;

% if error = 1, the algorithm will compute the relative and absolute error and
% apply the newton method on the first # Variables polynomials
% the output is a matrix with the following structure:
% we evaluate each polynomial at the computed roots and write down
% the relative error of the i-th polynomial at the j-th root; absolute error of the i-th polynomial at the j-th root; i the index of the i-th polynomial
error = 1;

% computing the roots of the system
Roots = Moment_Method_A(Vandermonde,A,Variables,tol,random,error)

% have a look at the polynomial system
Vandermonde;
