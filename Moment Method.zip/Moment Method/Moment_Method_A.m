function Real_Roots = Moment_Method_A(Polynomials,A,Variables,tol,random,error)

% this function computes the real roots of a given polynomial system, where
% the polynomials are given in the form Polynomials {f_1,...,f_m}, and each
% polynomial is given as f_i = {{[c_1],[x^alpha_1]},...,{[c_k],[x^alpha_k]}}
% Variables is an integer

% we will focus on Algorithm 3 in the Thesis

% tol discribes a tolerance for the rank computation

% random is true or false and discribes the SDP input. If true (= 1), the linear form c
% is chosen to be a random linear form. If random = false (= 0), then the linear form c
% is just [1,0,...,0]

% error is a parameter that is true or false. If true (=1), the output of the algorithm
% will compute the evaluations of all polynomials at all the solutions that we computed
% with this algorithm.  Further, the relative error will also be computed and we
% apply the newton algorithm to all the solutions that we computed.

% step (2) + (3)

Exponents = ExtractingExponents(Polynomials);
D = - inf;

Number_of_polynomials = length(Polynomials);

for k = 1:Number_of_polynomials
    D = max(D,degreePolynomial_A(Polynomials{k},A,Variables));
end

t = D;


T = 0;
number_of_Monomials = size(A);
Monomials = [];
for k = 1:number_of_Monomials(1)
    if isequal(A(k,:),zeros(1,Variables)) == 1
    Monomials = [Monomials ; A(k,:) 0];
    else
    Monomials = [Monomials ; A(k,:) 1];
    endif

endfor

for i = 2:D-1
  Monomials = Adding_A(Monomials,A,i,Variables);
endfor

% Monomials_2 = Construct_Monomials_A(t,Variables,A);

%while isequal(Monomials,Monomials_2)
%      Monomials
%      Monomials = Construct_Monomials_A(t+1,Variables,A)
%      size(Monomials)
%      Monomials_2 = Adding_A(Monomials_2,A,t+1,Variables)
%      size(Monomials_2)
%      t = t + 1
%endwhile

while T == 0

 %   Monomials = Construct_Monomials_A(t,Variables,A);
    Monomials = Adding_A(Monomials,A,t,Variables);


    [At,c,b,K] = SDP_Input_A(Polynomials,Monomials,A,Variables,t,random);

    pars.eps = 1e-3;
    pars.beta = 0.1;
    pars.theta = 0.1;
    [x,~,info] = sedumi(At,b,c,K,pars);
    info;

    %Number_of_Monomials = size(Monomials)
    %size_c = size(c)
    %mat(x(Number_of_Monomials(1) + 1:size_c(1)))
    %rank(mat(x(Number_of_Monomials(1) + 1:size_c(1))),tol)
    [Condition,order] = Rank_Condition_A(D,floor(t/2),x,Monomials,tol,Variables,A);
    if Condition == 0
        t = t + 1
    else
        % step (4)

        M_order = Moment_Matrix_A(x,order,Monomials,Variables,A);

Size_M = size(M_order);
rank(M_order,tol)
Solution_test = M_order(1,1:Size_M(1)) / M_order(1,1)

if rank(M_order,tol) == Size_M(1)
    Basis_J = zeros(Size_M(1),1);
else
    Basis_J = null(M_order,tol);
end

% avoid numerical problems

Size_J = size(Basis_J);
for column = 1:Size_J(2)
    for row = 1:Size_J(1)
        if abs(Basis_J(row,column)) < tol
            Basis_J(row,column) = 0;
        end
    end
end


% we compute a Basis of the quotient space corresponding to J and also the
% multiplication operators

% First, we need to represent the Basis of J as polynomials and not as
% vectors

Number_of_Monomials_now = size(Monomials);
Monomials_Now = Monomials(1:Number_of_Monomials_now(1),1:Variables);
%Monomials = Monomials_Now;

Polynomial_Basis = InverseCoefficient(Basis_J,Monomials_Now);

% we have to make sure that every polynomial in the polynomial basis is
% contained in R[x_1,...,x_n]. Therefore we need to multiply each
% polynomial by some monomial.


Polynomial_Basis = Monomial_Multiplication(Polynomial_Basis,Variables);

% We are now computing a border basis in order to compute the
% multiplication maps and apply the eigenvalue method

[Border_Basis,C_0] = BorderBasis(Polynomial_Basis,Variables,tol);
Size_of_Border_Basis = size(Border_Basis);
Size_Border = size(Border_Basis);

if Size_Border(1) == rank(M_order,tol) % && info.numerr < 2  % avoid numerical problems
   T = 1;
else
    t = t + 1;
end
    end
end


Multiplication_Maps = Multiplication_Operators(Border_Basis,C_0,Variables);

% Eigenvalue method
Multiplication_Random = zeros(Size_of_Border_Basis(1),Size_of_Border_Basis(1));

for i = 1:Variables
    Random_Coefficient = rand;
    Multiplication_Random = Multiplication_Random + Random_Coefficient * Multiplication_Maps(1:Size_of_Border_Basis(1),(i-1) * Size_of_Border_Basis(1) + 1:i * Size_of_Border_Basis(1));
end

Real_Roots = Eigenvalue_Method(Border_Basis,Multiplication_Random,Multiplication_Maps,Variables)

% number of columns of Real_Roots equals number of roots

Number_of_Roots = size(Real_Roots);

if error == 1


    % Computing all the evaluations

    Evaluations_Relative_Error_And_Polynomial = [];
    Relative_Error = - inf;
    for i = 1:Number_of_polynomials
        for j = 1:Number_of_Roots(1)
          if norm(Real_Roots(j,:)) > tol
              Evaluations_Relative_Error_And_Polynomial = [Evaluations_Relative_Error_And_Polynomial ; evaluation(Polynomials{i},Real_Roots(j,:),Variables) abs(evaluation(Polynomials{i},Real_Roots(j,:),Variables))/norm(Real_Roots(j,:),2) i];
              Relative_Error = max(Relative_Error, abs(evaluation(Polynomials{i},Real_Roots(j,:),Variables))/norm(Real_Roots(j,:),2));
          else
              Evaluations_Relative_Error_And_Polynomial = [Evaluations_Relative_Error_And_Polynomial ; evaluation(Polynomials{i},Real_Roots(j,:),Variables) inf i];
          endif
        endfor
    endfor

    Evaluations_Relative_Error_And_Polynomial

    % Computing the biggest Errors (relative and absolut error) w.r.t. the euclidean norm

    Absolut_Error = - inf;

    for evaluation_of_root = Evaluations_Relative_Error_And_Polynomial'
        Absolut_Error = max(Absolut_Error, abs(evaluation_of_root(1)));
    endfor

    Absolut_Error
    Relative_Error

    Newton_Polynomials = {};
    for polynomial = 1:Variables
       Newton_Polynomials{polynomial} = Polynomials{polynomial};
    endfor
    Newton = [];
    for i = 1:Variables
       %   Newton_solution = Newton_Method(Newton_Polynomials,Variables,Real_Roots(root,1:Variables),tol);
           for root = 1:Number_of_Roots
               Newton_solution = Newton_Method(Newton_Polynomials,Variables,Real_Roots(root,1:Variables),tol);
                   if norm(Newton_solution) > tol
                      Newton = [Newton ; evaluation(Newton_Polynomials{i},Newton_solution,Variables) abs(evaluation(Newton_Polynomials{i},Newton_solution,Variables))/norm(Newton_solution,2) i];
                   else
                      Newton = [Newton ; evaluation(Polynomials{i},Newton_solution,Variables) inf i];
                   endif

           endfor
    endfor
    Newton
endif
end
