function polynom = Multiplication_Polynomial(f,g)
  
  % multiplies to polynomials, that have the same number of variables
  
  polynom = {};
  
  monomials_f = length(f);
  monomials_g = length(g);
  
  for i = 1:monomials_f
    for j = 1:monomials_g
    new_monomial = f{i}{2} + g{j}{2};
    new_coefficient = f{i}{1} * g{j}{1};
    
    monomials_polynomial = length(polynom);
    T = 1;
      while T <= monomials_polynomial
         if ismember (new_monomial, polynom{T}{2}, "rows");
            polynom{T}{1} = polynom{T}{1} + new_coefficient;
            T = monomials_polynomial + 2;
         else
            T = T + 1;
         endif
         
      endwhile
    
     if T == monomials_polynomial + 1
        polynom{T} = {new_coefficient,new_monomial};
     endif
    
    endfor
  endfor
  
endfunction
