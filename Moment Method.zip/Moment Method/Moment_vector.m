function vector = Moment_vector(x,Degree,Variables)

% this function computes the moment vector of a given point 

Monomials = Construct_Monomials(Degree,Variables,zeros(1,Variables));
Number_of_Monomials = size(Monomials);
vector = [];
for k = 1:Number_of_Monomials
    vector = [vector evaluation({{[1],Monomials(k,:)}},x,Variables)];
end


end