function T = is_equal(A,B)

% T = 1 if and only if A and B are equal but maybe the rows are ordered
% different

rows = size(A);

for i = 1:rows(1)
        T = 1;
        if ismember(A(i,:),B,'rows') == 0
              T = 0;
         return
        end
end
         


