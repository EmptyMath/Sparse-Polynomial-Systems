function derivative = Derivative_Polynomial(Polynomial,Variables,Variable)

% computes the derivative of a polynomal w.r.t. to the variable Variable

  e_Variable = zeros(1,Variables);
  e_Variable(Variable) = 1;
  monomials = length(Polynomial);
  for monomial = 1:monomials
    derivative{monomial} = {Polynomial{monomial}{1} * Polynomial{monomial}{2}(Variable), Polynomial{monomial}{2} - e_Variable };
  endfor
endfunction
