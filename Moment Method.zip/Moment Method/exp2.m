f_1 = {{3,[13 4]},{-1,[12 5]},{-1,[0 0]},{-1,[6 2]}};
f_2 = {{6,[13 4]},{-1,[12 5]},{-3,[0 0]},{-2,[6 2]}};
f_3 = {{-1,[13 4]},{-1,[0 0]},{2,[6 2]}};
Polynomials = {f_1,f_2,f_3};
Variables = 2;

A = [0 0; 0 1; 1 0; 6 2; 13 4; 12 5];
tol = 1e-3;

random = 1;
error = 1;

Roots = Moment_Method_A(Polynomials,A,Variables,tol,random,error)