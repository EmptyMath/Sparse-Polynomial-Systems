function evaluation = evaluation(f,x,Variables)

% this function computes f(x), where f is a polynomial and x a point

evaluation = 0;
m = length(f);
for k = 1:m
    exponents = f{k}{2};
    mult = 1;
    for i = 1:Variables
      if x(i) == 0
        printf ('point has zero')
        return
      endif
        mult = mult * (x(i) ^ exponents(i));
    end
    evaluation = evaluation + f{k}{1} * mult;

end