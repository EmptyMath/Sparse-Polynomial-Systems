function [At,b,c,K] = SDP_Input_test(Polynomials,Monomials,Variables,order)

% this function computes the SDP input in SeDuMi format for the moment
% method, the constant term gets a sign '-' 
% the monomials are given as row vectors
% the polynomials are given in the form Polynomials {f_1,...,f_m}, and each
% polynomial is given as f_i = {{[c_1],[x^alpha_1]},...,{[c_k],[x^alpha_k]}}
% Variables is an integer

% the monomials have to have the same degree as the order, not more!

% switch b and c???

N = size(Monomials);
Number_of_monomials = N(1);
Number_of_polynomials = length(Polynomials);
Index_of_1 = 1;
while isequal(Monomials(Index_of_1,:),zeros(1,Variables)) == 0
    Index_of_1 = Index_of_1 + 1;
end

b = zeros(Number_of_monomials,1);
b(Index_of_1) = 1;

% which size does c have?

% Writing the At, which consists of the matrices A_j represented as column
% vectors

At = [];

for alpha = 1:Number_of_monomials
    A_alpha = [];
    Monomials(alpha,:);
    for i = 1:Number_of_polynomials
        deg_h_i = degreePolynomial(Polynomials{i});
        N = length(Polynomials{i});
        for beta = 1:Number_of_monomials
            if norm(Monomials(beta,:),1) <= order - deg_h_i
               c_i_alpha_beta = 0;

               % checking if alpha - beta is an exponent of h_i
               for k = 1:N
                   
                   if isequal(Monomials(alpha,:) - Monomials(beta,:), Polynomials{i}{k}{2}) == 1
                       c_i_alpha_beta = Polynomials{i}{k}{1};
                   end
               end

               A_alpha = blkdiag(A_alpha, [c_i_alpha_beta]);
            end
        end
        
        
        
    end
    if isequal(Monomials(alpha,:),zeros(1,Variables)) == 1
            A_alpha = blkdiag([1],A_alpha);
        else
            A_alpha = blkdiag([0],A_alpha);
        end
    
    % A_alpha = blkdiag(A_alpha,A_tilde_alpha)
    rows = size(A_alpha);
    % reshaping the matrix into a column vector
    % if rank(At) == rank([At reshape(A_alpha,[],1)])
    %    alpha
    %    Monomials(alpha,:)
    %    reshape(A_alpha,[],1)'
    % end
    At = [At reshape(A_alpha,[],1)];
   
end

% get the size for C out of At or A_alpha

C = blkdiag([-1], zeros(rows(1)-1,rows(2)-1));  

% c = -C because of SeDuMi input
c = -reshape(C,[],1);


Monomials_of_order_t_2 = 0;
for i = 1:Number_of_monomials
    if norm(Monomials(i,:),1) <= order/2
        Monomials_of_order_t_2 = Monomials_of_order_t_2 + 1;
    end
end

rows_At = size(At);
At = [At zeros(rows_At(1),Monomials_of_order_t_2^2)];

b = [b ; zeros(Monomials_of_order_t_2 ^2,1)];
c = [c ; zeros(Monomials_of_order_t_2 ^2,1)];


% Momonet matrix should be psd using new variables, and setting them es
% entries in the moment matrix by the constraint = 0
for alpha = 1:Number_of_monomials
if norm(Monomials(alpha,:),1) <= order
    New_constrains = [];
    y_alpha = zeros(1,Number_of_monomials);
    y_alpha(1,alpha) = 1;

    for i = 1:Number_of_monomials
        for j = 1:Number_of_monomials
            T = 0;
            if norm(Monomials(i,:),1) <= order/2 & norm(Monomials(j,:),1) <= order/2 & T == 0
                if isequal(Monomials(i,:) + Monomials(j,:), Monomials(alpha,:)) 
                    z_alpha = zeros(1,Monomials_of_order_t_2^2);
                    z_alpha(1,Monomials_of_order_t_2*(i-1)+j) = -1;
                    New_constrains = [New_constrains ; y_alpha z_alpha];
                    T = 1;
                end
            end
        end
    end
       At = [At ; New_constrains];
       %size(At)
   


end

end

L = [At c];
L = L(any(L,2),:);
size_L = size(L);
At = L(1:size_L(1),1:size_L(2)-1);
c = L(1:size_L(1),size_L(2));

% declare the free and sdp variables

K.f = Number_of_monomials;
if order == 1
    K.l = 1;
    K.s = 0;
else
    K.l = 0;
    K.s = Monomials_of_order_t_2;
end

end