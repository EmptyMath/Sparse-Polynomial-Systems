
f_1 = {{1,[2 0]},{1,[0 2]}};
f_2 = {{1,[0 2]},{-1,[0 0]}};
Polynomials = {f_1};
Variables = 2;

A = [0 0; 1 0; 0 1];
tol = 1e-5;

random = 1;
error = 1;

Roots = Moment_Method_A(Polynomials,A,Variables,tol,random,error)
