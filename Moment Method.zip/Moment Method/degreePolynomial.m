function degree = degreePolynomial(Polynomial)

N = length(Polynomial);
degree = - inf;
for i = 1:N
    degree = max(degree,norm(Polynomial{i}{2},1));
end

end