function polynom = SOS(Polynomials)
  
  number_polynomials = length(Polynomials);
  polynom = {};
  
  for i = 1:number_polynomials
    polynom = Adding_Polynomials(polynom,Multiplication_Polynomial(Polynomials{i},Polynomials{i}));  
  endfor
  
  
endfunction
