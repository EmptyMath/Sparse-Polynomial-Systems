function Basis = IterativeBorderBasis(Polynomials,Variables,R,Degree)

% this function computes the border basis iteratively, as described in
% Algorithm 2 

% Input: Polynomials, as ususal, Variables as usual, and R is given by a
% basis of monomials, represented as row vectors

% Now we constructing C_n, starting by C_0

Number_of_Polynomials = length(Polynomials);
Monomials_of_degree = Construct_Monomials(Degree,Variables,zeros(Variables,1)');

C_0 = [];

% We are going to represent C_0 as column vectors, where each column
% represents a polynomial contained in Polynomials

for i = 1:Number_of_Polynomials
    C_0 = [C_0 Coefficients(Polynomials{i},R)];
end


% we are now checking at which point C_n = C_{n+1}

C_n = Intersection_Spaces(Prolongation_times(C_0,Monomials_of_degree,Variables),R);
while Same_Spaces(C_0,C_n) == 0      
     C_0 = C_n;
     C_n = Intersection_Spaces(Prolongation_times(C_0,Monomials_of_degree,Variables),R); 
end

% we are now going to contsruct the basis B we start with the 1 and extend
% it in every dicretion and check if it is needed

B = [Coefficients({{[1],[zeros(Variables,1)']}},Monomials_of_degree)];

B = Construct_Basis(B,[Coefficients({{[1],[zeros(Variables,1)']}},Monomials_of_degree)],C_0,R,Variables,Monomials_of_degree);

% What is left, is to check if B^+ is a subset of R

if rank([Prolongation_plus(B,Monomials_of_degree,Variables) R]) == rank(R)
    Monomial_Basis = InverseCoefficient(B,Monomials_of_degree);
    Basis = [];
    for i = 1:length(Monomial_Basis)
        Basis = [Basis; Monomial_Basis{i}{1}{2}];
    end

else

    % we now need to represent R in a bigger vector space, hence we need to
    % compute it anew (maybe there is a better way)

    Cardinality_of_R = size(R); % we need the column size
    Basis_Exponents = InverseCoefficient(R,Monomials_of_degree);
    Monomials_of_degree_larger_N = Construct_Monomials(Degree + 1,Variables,zeros(Variables,1)');
    Number_of_monomials = size(Monomials_of_degree_larger_N); % number of rows is needed

    Basis_of_R = [Basis_Exponents{1}{1}{2}]; % rows represent basis vectors of R
for i = 1:Cardinality_of_R(2)
    exponent = Basis_Exponents{i}{1}{2};
    Basis_of_R = [Basis_of_R ; exponent];
    for j = 1:Variables % dividing by x_j, if possible, and adding it to R, hence making it connected to 1
        while exponent(j) - 1 >= 0
            exponent(j) = exponent(j) - 1;
            if ismember(exponent, Basis_of_R,'rows') == 0
                Basis_of_R = [Basis_of_R; exponent];
            end
        end
    end
end

    R = [];
    Cardinality_of_Basis_R = size(Basis_of_R);
    for i = 1:Cardinality_of_Basis_R(1)
    k = 1;
    while isequal(Basis_of_R(i,:),Monomials_of_degree_larger_N(k,:)) == 0
        k = k + 1;
    end
    Basis_vector = zeros(Number_of_monomials(1),1); % is already a column vector
    Basis_vector(k) = 1; % the k-th monomial in our Monomial basis Monomials_of_degree_N
    R = [R  Basis_vector];
    end

    Basis = IterativeBorderBasis(Polynomials,Variables,Prolongation_plus(R,Monomials_of_degree_larger_N,Variables),Degree + 1);

end

end