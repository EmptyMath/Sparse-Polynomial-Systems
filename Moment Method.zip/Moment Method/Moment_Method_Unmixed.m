function Real_Roots = Moment_Method_Unmixed(Polynomials,Variables)

% this function computes the real roots of a given polynomial system, where
% the polynomials are given in the form Polynomials {f_1,...,f_m}, and each
% polynomial is given as f_i = {{[c_1],[x^alpha_1]},...,{[c_k],[x^alpha_k]}}
% Variables is an integer

% we will focus on Algorithm 5 in the Thesis

% Extracting the Exponents from the polynomials in oder to compute a basis
% for the lattice K_A

Exponents = ExtractingExponents(Polynomials);
Number_of_Exponents = length(Exponents);

% Constructing a generating system for K_A,i.e. the affine lattice

alpha_1 = Exponents{1};

K_A_Generators = [];

for k = 2:Number_of_Exponents 
    K_A_Generators = [K_A_Generators (Exponents{k} - alpha_1)'];
end

K_A_Basis = Lattice_Basis(K_A_Generators);


end