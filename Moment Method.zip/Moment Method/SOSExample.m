% the Zero Set prescribes the Solutions of a random polynomial system constructed
% with the vandermonde matrix 
Zero_Set = [1 2; 2 3; 1 -1];

% Variables = Number of Coordinates of the solutions
Variables = 2;

% A = [0 0; 1 0; 0 1] since we want to focus on the standard moment approach first
% in general A = [0 ... 0; e_1 ; ... ; e_{Variables}]
A = [0 0;1 0; 0 1];

% the total degree of the polynomials constructed with the Vandermonde Matrix
Degree = 3;

% tol prescribes the precision of the solutions
% it seems best to use bigger tol instead of smaller ones...
tol = 1e-4;

% Constructing a SOS polynomial arising from a polynomial system using the vandermonde 
% matrix consisting of Variables + 1 polynomials
Vandermonde = Vanishing_Generators(Zero_Set,Variables,A,Degree,tol);

% creating the SOS 
Polynom = SOS(Vandermonde);

% if random = 1, the SDP will be solved using a random vector (therefore, we 
% expect only one solution to be computed)
% if random = 0, we use the standard moment method
random = 0;

% here error must be = 0 since the Newton method can not be applied.
error = 0;

% computing the roots of the system
Roots = Moment_Method_A({Polynom},A,Variables,tol,random,error)

% have a look at the polynomial system 
Vandermonde;