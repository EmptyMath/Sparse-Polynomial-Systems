function Jacobi_Matrix = Jacobi(Polynomial,Variables,point)
  Jacobi = zeros(1:Variables,1:Variables);
  for i = 1:Variables
    for j = 1:Variables
      Jacobi(i,j) = evaluation(Derivative_Polynomial(Derivative_Polynomial(Polynomial,Variables,i),Variables,j),point,Variables);
    endfor
  endfor
  Jacobi
endfunction
