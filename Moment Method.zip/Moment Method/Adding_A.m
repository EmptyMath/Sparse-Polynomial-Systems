function B = Adding_A(Monomials,A,D,Variables)

% this function adds A to all Monomials

Number_A = size(A);
Monomials_of_Degree_D_1 = [];
Number_Monomials = size(Monomials);
Monomials;

for i = 1:Number_Monomials(1)
    if Monomials(i,Variables+ 1) == D-1
      Monomials_of_Degree_D_1 = [Monomials_of_Degree_D_1; Monomials(i,1:Variables+1)];
    endif
endfor

Number_Monomials_of_Degree_D_1 = size(Monomials_of_Degree_D_1);

for i = 1:Number_Monomials_of_Degree_D_1(1)
    for k = 1:Number_A(1)
        new_monomial = Monomials_of_Degree_D_1(i,1:Variables) + A(k,:);

        if ismember(new_monomial, Monomials_of_Degree_D_1(1:Number_Monomials_of_Degree_D_1(1),1:Variables),'rows') == 0


            Monomials = [Monomials ; new_monomial D];
            Monomials_of_Degree_D_1 = [Monomials_of_Degree_D_1; new_monomial D];
            Number_Monomials_of_Degree_D_1 = size(Monomials_of_Degree_D_1);
            Number_Monomials = size(Monomials);
        end
    end
end

B = Monomials;

end
